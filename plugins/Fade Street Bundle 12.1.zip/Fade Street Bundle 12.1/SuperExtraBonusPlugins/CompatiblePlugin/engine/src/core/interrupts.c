/*
  Do not add anything to this file.
  
  Add your own interrupt code to compatible_interrupts.c
 */

extern char suppress_warnings;
