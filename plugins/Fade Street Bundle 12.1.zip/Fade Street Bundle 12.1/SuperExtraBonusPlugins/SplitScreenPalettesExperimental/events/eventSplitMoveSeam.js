/*
      ___          ___
     /  /\        /  /\                 ___          ___
    /  /:/_      /  /::\               /  /\        /  /\
   /  /:/ /\    /  /:/\:\___     ___  /  /:/       /  /:/
  /  /:/ /::\  /  /:/~/:/__/\   /  /\/__/::\      /  /:/
 /__/:/ /:/\:\/__/:/ /:/\  \:\ /  /:/\__\/\:\__  /  /::\
 \  \:\/:/~/:/\  \:\/:/  \  \:\  /:/    \  \:\/\/__/:/\:\
  \  \::/ /:/  \  \::/    \  \:\/:/      \__\::/\__\/  \:\
   \__\/ /:/    \  \:\     \  \::/       /__/:/      \  \:\
     /__/:/      \  \:\     \__\/        \__\/        \__\/
     \__\/        \__\/
 <............................................................................>
      ___          ___          ___         ___          ___          ___
     /  /\        /  /\        /  /\       /  /\        /  /\        /__/\
    /  /:/_      /  /:/       /  /::\     /  /:/_      /  /:/_       \  \:\
   /  /:/ /\    /  /:/       /  /:/\:\   /  /:/ /\    /  /:/ /\       \  \:\
  /  /:/ /::\  /  /:/  ___  /  /:/~/:/  /  /:/ /:/_  /  /:/ /:/_  _____\__\:\
 /__/:/ /:/\:\/__/:/  /  /\/__/:/ /:/__/__/:/ /:/ /\/__/:/ /:/ /\/__/::::::::\
 \  \:\/:/~/:/\  \:\ /  /:/\  \:\/:::::|  \:\/:/ /:/\  \:\/:/ /:/\  \:\~~\~~\/
  \  \::/ /:/  \  \:\  /:/  \  \::/~~~~ \  \::/ /:/  \  \::/ /:/  \  \:\  ~~~
   \__\/ /:/    \  \:\/:/    \  \:\      \  \:\/:/    \  \:\/:/    \  \:\
     /__/:/      \  \::/      \  \:\      \  \::/      \  \::/      \  \:\
     \__\/        \__\/        \__\/       \__\/        \__\/        \__\/
 <............................................................................>
      ___      ___                     ___
     /  /\    /  /\                   /  /\
    /  /::\  /  /::\                 /  /:/_
   /  /:/\:\/  /:/\:\  ___     ___  /  /:/ /\
  /  /:/~/:/  /:/~/::\/__/\   /  /\/  /:/ /::\
 /__/:/ /:/__/:/ /:/\:\  \:\ /  /:/__/:/ /:/\:\
 \  \:\/:/\  \:\/:/__\/\  \:\  /:/\  \:\/:/~/:/
  \  \::/  \  \::/      \  \:\/:/  \  \::/ /:/
   \  \:\   \  \:\       \  \::/    \__\/ /:/
    \  \:\   \  \:\       \__\/       /__/:/
     \__\/    \__\/                   \__\/

	https://gearfo.itch.io/fade-street
*/

const id = "GF_EVENT_SPLIT_MOVE_SEAM";
const groups = ["Split Screen Palettes"];
const subGroups = {"Split Screen Palettes": "Configure Split"};
const description = "Set the y position of the seam.";
const name = "Move Split Screen Seam";

const autoLabel = (fetchArg) => {

	const src = fetchArg("source");
	if (src === "const") {
		const lyc = fetchArg("lyc_const");
		return `Move Split Screen Seam to Line (${lyc})`;
	} else if (src === "var") {
		const lyc = fetchArg("lyc_var");
		return `Move Split Screen Seam to (${lyc_var})`;
	}
	else return "test";
}

const fields = [
	{
		key: "source",
		label: "Set from:",
		type: "select",
		options: [
			["const", "constant"],
			["var", "variable"],
		],
		defaultValue: "const",
	},
	{
		conditions: [
			{
				key: "source",
				eq: "const",

			}
		],
		key: "lyc_const",
		label: "Seam Start (line):",
		description: "Screen y coordinate where the seam begins. The seam may by more than one line high.",
		defaultValue: 64,
		type: "number",
		min: 0,
		max: 143
	},
	{
		conditions: [
			{
				key: "source",
				eq: "var",

			}
		],
		key: "lyc_var",
		label: "Source variable:",
		description: "Variable holding the y value of the new seam.",
		defaultValue: 64,
		type:"variable",
		defaultValue: "LAST_VARIABLE", 
	},

];

const compile = (input, helpers) => {
	const { _addComment, appendRaw, getVariableAlias } = helpers;


	let gbvm = "";

	if (input.source === "const") {
		gbvm += `VM_SET_CONST_UINT8 _split_y ${input.lyc_const}`;
	} else {
		const variable = getVariableAlias(input.lyc_var);
		gbvm += `VM_SET_UINT8 _split_y ${variable}`;
	}

	const logo = `
;     ___          ___
;    /  /\\        /  /\\                 ___          ___
;   /  /:/_      /  /::\\               /  /\\        /  /\\
;  /  /:/ /\\    /  /:/\\:\\___     ___  /  /:/       /  /:/
; /  /:/ /::\\  /  /:/~/:/__/\\   /  /\\/__/::\\      /  /:/
;/__/:/ /:/\\:\\/__/:/ /:/\\  \\:\\ /  /:/\\__\\/\\:\\__  /  /::\\
;\\  \\:\\/:/~/:/\\  \\:\\/:/  \\  \\:\\  /:/    \\  \\:\\/\\/__/:/\\:\\
; \\  \\::/ /:/  \\  \\::/    \\  \\:\\/:/      \\__\\::/\\__\\/  \\:\\
;  \\__\\/ /:/    \\  \\:\\     \\  \\::/       /__/:/      \\  \\:\\
;    /__/:/      \\  \\:\\     \\__\\/        \\__\\/        \\__\\/
;    \\__\\/        \\__\\/
;<............................................................................>
;     ___          ___          ___         ___          ___          ___
;    /  /\\        /  /\\        /  /\\       /  /\\        /  /\\        /__/\\
;   /  /:/_      /  /:/       /  /::\\     /  /:/_      /  /:/_       \\  \\:\\
;  /  /:/ /\\    /  /:/       /  /:/\\:\\   /  /:/ /\\    /  /:/ /\\       \\  \\:\\
; /  /:/ /::\\  /  /:/  ___  /  /:/~/:/  /  /:/ /:/_  /  /:/ /:/_  _____\\__\\:\\
;/__/:/ /:/\\:\\/__/:/  /  /\\/__/:/ /:/__/__/:/ /:/ /\\/__/:/ /:/ /\\/__/::::::::\\
;\\  \\:\\/:/~/:/\\  \\:\\ /  /:/\\  \\:\\/:::::|  \\:\\/:/ /:/\\  \\:\\/:/ /:/\\  \\:\\~~\\~~\\/
; \\  \\::/ /:/  \\  \\:\\  /:/  \\  \\::/~~~~ \\  \\::/ /:/  \\  \\::/ /:/  \\  \\:\\  ~~~
;  \\__\\/ /:/    \\  \\:\\/:/    \\  \\:\\      \\  \\:\\/:/    \\  \\:\\/:/    \\  \\:\\
;    /__/:/      \\  \\::/      \\  \\:\\      \\  \\::/      \\  \\::/      \\  \\:\\
;    \\__\\/        \\__\\/        \\__\\/       \\__\\/        \\__\\/        \\__\\/
;<............................................................................>
;     ___      ___                     ___
;    /  /\\    /  /\\                   /  /\\
;   /  /::\\  /  /::\\                 /  /:/_
;  /  /:/\\:\\/  /:/\\:\\  ___     ___  /  /:/ /\\
; /  /:/~/:/  /:/~/::\\/__/\\   /  /\\/  /:/ /::\\
;/__/:/ /:/__/:/ /:/\\:\\  \\:\\ /  /:/__/:/ /:/\\:\\
;\\  \\:\\/:/\\  \\:\\/:/__\\/\\  \\:\\  /:/\\  \\:\\/:/~/:/
; \\  \\::/  \\  \\::/      \\  \\:\\/:/  \\  \\::/ /:/
;  \\  \\:\\   \\  \\:\\       \\  \\::/    \\__\\/ /:/
;   \\  \\:\\   \\  \\:\\       \\__\\/       /__/:/
;    \\__\\/    \\__\\/                   \\__\\/
;
`
	_addComment(logo);
	_addComment(`            Move Split Screen Seam`);
	_addComment(`          [GF_EVENT_SPLIT_MOVE_SEAM]`);
	_addComment("");
	appendRaw(gbvm);
	_addComment(`~~~ End of Move Split Screen Seam block ~~~\n\n`);
};

module.exports = {
	id,
	autoLabel,
	name,
	groups,
	subGroups,
	description,
	fields,
	compile,
	waitUntilAfterInitFade: true,
};

function components(rgb) {
	var r = (parseInt(rgb[0] + rgb[1], 16) / 8) / 31;
	var g = (parseInt(rgb[2] + rgb[3], 16) / 8) / 31;
	var b = (parseInt(rgb[4] + rgb[5], 16) / 8) / 31;
	return [r, g, b]
}

function ubh(p) {
	switch (p % 8) {
		case 0:
		case 5:
			return " 3, 19, 12,   ";
		case 1:
		case 6:
			return "31, 31, 31,   ";
		case 2:
		case 7:
			return "31, 17,  8,   ";
		case 3:
			return " 0,  0,  0,   ";
		case 4:
			return " 0,  0,  0,   ";
	}
}

function linear_RGB_to_OKLab(r, g, b)
{
	let l = 0.4122214708 * r + 0.5363325363 * g + 0.0514459929 * b;
	let m = 0.2119034982 * r + 0.6806995451 * g + 0.1073969566 * b;
	let s = 0.0883024619 * r + 0.2817188376 * g + 0.6299787005 * b;
	l = Math.cbrt(l);
	m = Math.cbrt(m);
	s = Math.cbrt(s);
	const OK_L = 0.2104542553 * l + 0.7936177850 * m - 0.0040720468 * s;
	const OK_a = 1.9779984951 * l - 2.4285922050 * m + 0.4505937099 * s;
	const OK_b = 0.0259040371 * l + 0.7827717662 * m - 0.8086757660 * s;
	return [OK_L, OK_a, OK_b];
}

function OKLab_to_linear_RGB(OK_L, OK_a, OK_b)
{
	let l = OK_L + 0.3963377774 * OK_a + 0.2158037573 * OK_b;
	let m = OK_L - 0.1055613458 * OK_a - 0.0638541728 * OK_b;
	let s = OK_L - 0.0894841775 * OK_a - 1.2914855480 * OK_b;

	l = l * l * l;
	m = m * m * m;
	s = s * s * s;

	let r =  4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s;
	let g = -1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s;
	let b = -0.0041960863 * l - 0.7034186147 * m + 1.7076147010 * s;

	return [r, g, b];
}

function OKLab_to_GB(OK_L, OK_a, OK_b)
{
	let [r, g, b] =  OKLab_to_linear_RGB(OK_L, OK_a, OK_b);

	r = Math.min(31, Math.round(31 * Math.max(r, 0)));
	g = Math.min(31, Math.round(31 * Math.max(g, 0)));
	b = Math.min(31, Math.round(31 * Math.max(b, 0)));

	return [r, g, b];
}

function OKLab_to_hex(OK_L, OK_a, OK_b)
{
	let [r, g, b] = OKLab_to_GB(OK_L, OK_a, OK_b);

	let r2 = (8 * r).toString(16).padStart(2, '0');
    	let g2 = (8 * g).toString(16).padStart(2, '0');
    	let b2 = (8 * b).toString(16).padStart(2, '0');

	return `${r2}${g2}${b2}`;
}

function OKLCh_to_OKLab(L, C, h)
{
	const a = C * Math.cos(h);
	const b = C * Math.sin(h);
	return [L, a, b];
}

function OKLab_to_OKLCh(OK_L, OK_a, OK_b)
{
	const C = Math.sqrt(OK_a * OK_a + OK_b * OK_b);
	const h = Math.atan2(OK_b, OK_a);
	return [OK_L, C, h];
}

function OKLCh_to_linear_RGB(L, C, h)
{
	const [OK_L, OK_a, OK_b] = OKLCh_to_OKLab(L, C, h);
	return OKLab_to_linear_RGB(OK_L, OK_a, OK_b);
}


