extern char suppress_warnings;
