#pragma bank 255

#include <gbdk/platform.h>
#include <string.h>

#include "interrupts.h"

#include "system.h"
#include "split_palette.h"
#include "scroll.h"
#include "palette.h"
#include "parallax.h"
#include "ui.h"
#include "vm.h"

#include "data/states_defines.h"

#define LYC_SYNC_VALUE 150u

uint8_t split_y;

UBYTE hide_sprites = FALSE;
UBYTE show_actors_on_overlay = FALSE;
UBYTE overlay_cut_scanline = LYC_SYNC_VALUE;

bool refresh_bkg2_palettes;

void split_LCD_isr(void) NONBANKED
{
	uint8_t saved_bank = _current_ram_bank;
	SWITCH_RAM(3);
	set_bkg_palette(0, 8, (palette_color_t *)BkgPalette2);
	refresh_bkg_palettes = true;
	SWITCH_RAM(saved_bank);
}

void remove_LCD_ISRs(void) BANKED {
    CRITICAL {
        remove_LCD(parallax_LCD_isr);
        remove_LCD(simple_LCD_isr);
        remove_LCD(split_LCD_isr);
        remove_LCD(fullscreen_LCD_isr);
        LCDC_REG &= ~LCDCF_BG8000;
    }
}

void simple_LCD_isr(void) NONBANKED {
    if (LYC_REG == LYC_SYNC_VALUE) {
        SCX_REG = draw_scroll_x;
        SCY_REG = draw_scroll_y;
        if (WY_REG) {
            if (WY_REG < MENU_CLOSED_Y) LYC_REG = WY_REG - 1;
        } else {
            if ((WX_REG == DEVICE_WINDOW_PX_OFFSET_X) && (show_actors_on_overlay == FALSE)) HIDE_SPRITES;
            LYC_REG = overlay_cut_scanline;
        }
    } else {
        if (LYC_REG < overlay_cut_scanline) {
            if ((WX_REG == DEVICE_WINDOW_PX_OFFSET_X) && (show_actors_on_overlay == FALSE)) {
                while (STAT_REG & STATF_BUSY) ;
                HIDE_SPRITES;
            }
            LYC_REG = overlay_cut_scanline;
        } else {
            while (STAT_REG & STATF_BUSY) ;
            WX_REG = 0, HIDE_WIN;
            if (!hide_sprites) SHOW_SPRITES;
            LYC_REG = LYC_SYNC_VALUE;
            return;
        }
    }
}

void add_split_isr(void) BANKED
{
	remove_LCD_ISRs();
	add_LCD(split_LCD_isr);
        return;
}

void remove_split_isr(void) BANKED
{
	remove_LCD_ISRs();
	add_LCD(simple_LCD_isr);
}

void fullscreen_LCD_isr(void) NONBANKED {
    if (LYC_REG == LYC_SYNC_VALUE) {
        LCDC_REG &= ~LCDCF_BG8000;
        SCX_REG = draw_scroll_x;
        SCY_REG = draw_scroll_y;
        LYC_REG = (9 * 8) - 1;
    } else {
        while (STAT_REG & STATF_BUSY) ;
        LCDC_REG |= LCDCF_BG8000;
        LYC_REG = LYC_SYNC_VALUE;
    }
}


#ifndef GF_FADE_STREET_INSTALLED
void VBL_isr(void) NONBANKED {
    if ((WY_REG = win_pos_y) < MENU_CLOSED_Y) WX_REG = (win_pos_x + DEVICE_WINDOW_PX_OFFSET_X), SHOW_WIN; else WX_REG = 0, HIDE_WIN;
    if (hide_sprites) HIDE_SPRITES; else SHOW_SPRITES;
    scroll_shadow_update();
}
#endif

