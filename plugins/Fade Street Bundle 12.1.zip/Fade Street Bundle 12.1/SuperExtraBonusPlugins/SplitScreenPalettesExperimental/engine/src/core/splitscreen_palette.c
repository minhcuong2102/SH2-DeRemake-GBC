#pragma bank 255

#include <gbdk/platform.h>

#pragma bank 255

#include <gbdk/platform.h>

#include "system.h"
#include "gbs_types.h"
#include "vm_palette.h"

#include "vm.h"
#include "bankdata.h"
#include "data/states_defines.h"

BANKREF(VM_SPLITSCREEN)

palette_color_t __at(0xA000) BkgPalette2[32];

void vm_load_lower_palette(SCRIPT_CTX * THIS, UBYTE mask, UBYTE options) OLDCALL BANKED {
    UBYTE bank = THIS->bank;
    UBYTE is_bkg = (options & PALETTE_BKG);
    const palette_entry_t * sour = (const palette_entry_t *)THIS->PC;
    palette_entry_t * dest = (palette_entry_t *)BkgPalette2;
    SWITCH_RAM(3);
    for (UBYTE i = mask, nb = 0; (i != 0); dest++, nb++, i >>= 1) {
        if ((i & 1) == 0) {
		continue;
	}
	MemcpyBanked(dest, sour, sizeof(palette_entry_t), bank);
        sour++;
    }
    THIS->PC = (UBYTE *)sour;
}


