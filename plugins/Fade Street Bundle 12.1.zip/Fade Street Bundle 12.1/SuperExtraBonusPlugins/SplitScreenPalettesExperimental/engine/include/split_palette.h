#ifndef GF_SPLIT_PALETTE_H_INCLUDED
#define GF_SPLIT_PALETTE_H_INCLUDED

#include <gbdk/platform.h>
#include <stdbool.h>
#include "vm.h"

BANKREF_EXTERN(VM_SPLITSCREEN)

extern bool refresh_bkg_palettes;
extern palette_color_t __at(0xA000) BkgPalette2[32];
void vm_load_lower_palette(SCRIPT_CTX * THIS) OLDCALL NONBANKED;

#endif 
