#pragma bank 255

#include <gbdk/platform.h>
#include "system.h"
#include "vm.h"
#include "ui.h"


void vm_set_overlay_pos_ex(SCRIPT_CTX * THIS) OLDCALL BANKED {	
	uint8_t pos_x = *(int8_t*)VM_REF_TO_PTR(FN_ARG0);
	uint8_t pos_y = *(int8_t*)VM_REF_TO_PTR(FN_ARG1);
	ui_set_pos(pos_x, pos_y);
}